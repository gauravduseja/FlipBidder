package org.example.service2;

import org.example.model.Command;

public interface CommandExecutor {

    void executeCommand(Command command);
}
