package org.example.helper;

public class Constants {

    public static String getValue(String input) {
        return "";
    }
}
